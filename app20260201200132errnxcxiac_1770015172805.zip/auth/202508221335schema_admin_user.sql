INSERT INTO ${schema}.users ( email, password,role)
VALUES
    ('${schema_admin_user_email}', '${schema_admin_user_password}','${schema_admin_user}');
