
'use client';

// This component is now deprecated and replaced by AppLayout
// Keeping for backward compatibility if needed
export function Header() {
  return null;
}
